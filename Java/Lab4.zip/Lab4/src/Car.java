public class Car<T> extends Vehicle<T> {
}
