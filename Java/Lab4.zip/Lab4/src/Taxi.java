public class Taxi<T> extends Car<T> {
}
