public class FireEngine<T> extends Car<T> {
    
}
