public class PoliceCar<T> extends Car<T> {

}
