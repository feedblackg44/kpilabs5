public abstract class Vehicle<T> {

}
