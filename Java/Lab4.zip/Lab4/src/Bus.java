public class Bus<T> extends Vehicle<T> {
}
