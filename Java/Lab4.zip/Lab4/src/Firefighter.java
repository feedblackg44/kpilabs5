public class Firefighter extends Person {
}
