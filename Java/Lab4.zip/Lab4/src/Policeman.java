public class Policeman extends Person {
}
